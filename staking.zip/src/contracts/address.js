// export const GoldAddress = "0xD556Be2846DC9da80C3551D83c42A7Ad94bdADD8";
// export const PirateAddress = "0x62365089075e3FC959952134c283e0375b49F648";
// export const StakeContract = "0x62365089075e3FC959952134c283e0375b49F648";

// Test Addresses
export const GoldAddress = "0x871924FD30167CA8a9990392a0d25c2c32676f26";
export const PirateAddress = "0x6ba4287ecc380f8d2c718114909c43f23f9da876";
export const StakeAddress = "0x6626bda9c85d722ced4041660b0fbd3bfb37bff2";

// export const GoldAddress = "0x52D4Eb58cbA4E46dA6B2533F1e31833Fc8Ae7Ac9";
// export const PirateAddress = "0xff10a49ea4387e00e1aBF6AD8a20D43d1B0c3300";
// export const StakeAddress = "0x8850Fff101a5A23996656975cEA6FDbE76Cf835a";

//Test Address
export const SimpleStakingAddress = "0x3A1aBfE41879245Dce46fFF2D38881cD0a14Cd60";
export const MTWTokenAddress = "0x4E24837A80E3b6345d5df843e84F42875F025121";
export const MTWkeyTokenAddress = "0x6f2C5b856CEa3D28FbEe91A3e6c8fdEa36E2FBb9";





export const metadataUrl =
  "https://etherpirates.mypinata.cloud/ipfs/QmRLaDsGY1zzkSkXx4Ak68Ax29sE9SVr6rtw32u51iLa3x/";
export const imageUrl =
  "https://etherpirates.mypinata.cloud/ipfs/QmUwJfKMaqonASM1Y3gz659oYR9B7BoXyJ7qF7F8KEtKCu/";
